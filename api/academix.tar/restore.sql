--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "academixDB";
--
-- Name: academixDB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "academixDB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en-US';


ALTER DATABASE "academixDB" OWNER TO postgres;

\connect "academixDB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: assignment_submissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assignment_submissions (
    id bigint NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    assignment_id bigint NOT NULL,
    student_id bigint NOT NULL,
    submission character varying(255),
    marks bigint,
    feedback text
);


ALTER TABLE public.assignment_submissions OWNER TO postgres;

--
-- Name: assignment_submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.assignment_submissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.assignment_submissions_id_seq OWNER TO postgres;

--
-- Name: assignment_submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.assignment_submissions_id_seq OWNED BY public.assignment_submissions.id;


--
-- Name: assignments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.assignments (
    id bigint NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    serial bigint,
    course_code text NOT NULL,
    instructions text,
    publish_time timestamp with time zone NOT NULL,
    deadline timestamp with time zone NOT NULL,
    question character varying(255)
);


ALTER TABLE public.assignments OWNER TO postgres;

--
-- Name: assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.assignments_id_seq OWNER TO postgres;

--
-- Name: assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.assignments_id_seq OWNED BY public.assignments.id;


--
-- Name: course_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course_models (
    id bigint NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    code text NOT NULL,
    title text NOT NULL,
    description text
);


ALTER TABLE public.course_models OWNER TO postgres;

--
-- Name: course_models_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.course_models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.course_models_id_seq OWNER TO postgres;

--
-- Name: course_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.course_models_id_seq OWNED BY public.course_models.id;


--
-- Name: instructor_courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.instructor_courses (
    course_model_id bigint NOT NULL,
    course_model_code text NOT NULL,
    user_model_id bigint NOT NULL
);


ALTER TABLE public.instructor_courses OWNER TO postgres;

--
-- Name: user_courses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_courses (
    course_model_id bigint NOT NULL,
    course_model_code text NOT NULL,
    user_model_id bigint NOT NULL
);


ALTER TABLE public.user_courses OWNER TO postgres;

--
-- Name: user_models; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_models (
    id bigint NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    deleted_at timestamp with time zone,
    name text NOT NULL,
    username text,
    email text,
    password text NOT NULL,
    role text NOT NULL
);


ALTER TABLE public.user_models OWNER TO postgres;

--
-- Name: user_models_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_models_id_seq OWNER TO postgres;

--
-- Name: user_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_models_id_seq OWNED BY public.user_models.id;


--
-- Name: assignment_submissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignment_submissions ALTER COLUMN id SET DEFAULT nextval('public.assignment_submissions_id_seq'::regclass);


--
-- Name: assignments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments ALTER COLUMN id SET DEFAULT nextval('public.assignments_id_seq'::regclass);


--
-- Name: course_models id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_models ALTER COLUMN id SET DEFAULT nextval('public.course_models_id_seq'::regclass);


--
-- Name: user_models id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_models ALTER COLUMN id SET DEFAULT nextval('public.user_models_id_seq'::regclass);


--
-- Data for Name: assignment_submissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assignment_submissions (id, created_at, updated_at, deleted_at, assignment_id, student_id, submission, marks, feedback) FROM stdin;
\.
COPY public.assignment_submissions (id, created_at, updated_at, deleted_at, assignment_id, student_id, submission, marks, feedback) FROM '$$PATH$$/4905.dat';

--
-- Data for Name: assignments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.assignments (id, created_at, updated_at, deleted_at, serial, course_code, instructions, publish_time, deadline, question) FROM stdin;
\.
COPY public.assignments (id, created_at, updated_at, deleted_at, serial, course_code, instructions, publish_time, deadline, question) FROM '$$PATH$$/4903.dat';

--
-- Data for Name: course_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course_models (id, created_at, updated_at, deleted_at, code, title, description) FROM stdin;
\.
COPY public.course_models (id, created_at, updated_at, deleted_at, code, title, description) FROM '$$PATH$$/4899.dat';

--
-- Data for Name: instructor_courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.instructor_courses (course_model_id, course_model_code, user_model_id) FROM stdin;
\.
COPY public.instructor_courses (course_model_id, course_model_code, user_model_id) FROM '$$PATH$$/4900.dat';

--
-- Data for Name: user_courses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_courses (course_model_id, course_model_code, user_model_id) FROM stdin;
\.
COPY public.user_courses (course_model_id, course_model_code, user_model_id) FROM '$$PATH$$/4901.dat';

--
-- Data for Name: user_models; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_models (id, created_at, updated_at, deleted_at, name, username, email, password, role) FROM stdin;
\.
COPY public.user_models (id, created_at, updated_at, deleted_at, name, username, email, password, role) FROM '$$PATH$$/4897.dat';

--
-- Name: assignment_submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.assignment_submissions_id_seq', 4, true);


--
-- Name: assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.assignments_id_seq', 3, true);


--
-- Name: course_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.course_models_id_seq', 3, true);


--
-- Name: user_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_models_id_seq', 3, true);


--
-- Name: assignment_submissions assignment_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignment_submissions
    ADD CONSTRAINT assignment_submissions_pkey PRIMARY KEY (id);


--
-- Name: assignments assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT assignments_pkey PRIMARY KEY (id);


--
-- Name: course_models course_models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_models
    ADD CONSTRAINT course_models_pkey PRIMARY KEY (id, code);


--
-- Name: instructor_courses instructor_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructor_courses
    ADD CONSTRAINT instructor_courses_pkey PRIMARY KEY (course_model_id, course_model_code, user_model_id);


--
-- Name: course_models uni_course_models_code; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course_models
    ADD CONSTRAINT uni_course_models_code UNIQUE (code);


--
-- Name: user_models uni_user_models_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_models
    ADD CONSTRAINT uni_user_models_email UNIQUE (email);


--
-- Name: user_models uni_user_models_username; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_models
    ADD CONSTRAINT uni_user_models_username UNIQUE (username);


--
-- Name: user_courses user_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_courses
    ADD CONSTRAINT user_courses_pkey PRIMARY KEY (course_model_id, course_model_code, user_model_id);


--
-- Name: user_models user_models_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_models
    ADD CONSTRAINT user_models_pkey PRIMARY KEY (id);


--
-- Name: idx_assignment_submissions_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignment_submissions_deleted_at ON public.assignment_submissions USING btree (deleted_at);


--
-- Name: idx_assignments_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_assignments_deleted_at ON public.assignments USING btree (deleted_at);


--
-- Name: idx_course_models_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_course_models_deleted_at ON public.course_models USING btree (deleted_at);


--
-- Name: idx_user_models_deleted_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_models_deleted_at ON public.user_models USING btree (deleted_at);


--
-- Name: assignment_submissions fk_assignment_submissions_assignment; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignment_submissions
    ADD CONSTRAINT fk_assignment_submissions_assignment FOREIGN KEY (assignment_id) REFERENCES public.assignments(id) ON DELETE CASCADE;


--
-- Name: assignments fk_course_models_assignments; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignments
    ADD CONSTRAINT fk_course_models_assignments FOREIGN KEY (course_code) REFERENCES public.course_models(code);


--
-- Name: instructor_courses fk_instructor_courses_course_model; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructor_courses
    ADD CONSTRAINT fk_instructor_courses_course_model FOREIGN KEY (course_model_id, course_model_code) REFERENCES public.course_models(id, code);


--
-- Name: instructor_courses fk_instructor_courses_user_model; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.instructor_courses
    ADD CONSTRAINT fk_instructor_courses_user_model FOREIGN KEY (user_model_id) REFERENCES public.user_models(id);


--
-- Name: user_courses fk_user_courses_course_model; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_courses
    ADD CONSTRAINT fk_user_courses_course_model FOREIGN KEY (course_model_id, course_model_code) REFERENCES public.course_models(id, code);


--
-- Name: user_courses fk_user_courses_user_model; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_courses
    ADD CONSTRAINT fk_user_courses_user_model FOREIGN KEY (user_model_id) REFERENCES public.user_models(id);


--
-- Name: assignment_submissions fk_user_models_submissions; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.assignment_submissions
    ADD CONSTRAINT fk_user_models_submissions FOREIGN KEY (student_id) REFERENCES public.user_models(id);


--
-- PostgreSQL database dump complete
--

